/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package mypackage;

/**
 *
 * @author drago
 */
public class LostItemOwner extends User{
    public void FillsLostItemForm(){
        
    }
    public void CheckNotifications(){
        
    }
    public void ChooseDropoffPoint(){
        
    }
    public void FillForm(){
        
    }
    public void VerifyPickup(){
        
    }
    public void LiveChat(){
        
    }
    public void FillsCardData(){
        
    }
    public void CreateReport(){
        
    }
    public void TransferReward(){
        
    }
    public void OwnThisItem(){
        
    }
    public void MyPosts(){
        
    }
    public void ChoosePost(){
        
    }
    public void RateFinder(){
        
    }
}
