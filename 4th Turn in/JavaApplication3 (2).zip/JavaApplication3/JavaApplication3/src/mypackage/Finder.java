/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package mypackage;

/**
 *
 * @author 30690
 */
public class Finder extends User{
    public void FillFoundItemForm(){
        
    }
    public void FoundThisItem(){
             
    }
    public void CheckNotifications(){
        
    }
    public void AcceptForm(){
    
    }
    public void ConfirmDropOff(){
        
    }
    public void FillsCardData(){
        
    }
}
