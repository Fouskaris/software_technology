
/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package mypackage;

/**
 *
 * @author drago
 */
public class User {
    String name=" ";
    private String Pass=" ";
    enum Type{test,bus,mod};//user,business owner, moderator
    String Firstname=" ";
    String Lastname=" ";
    String email=" ";
    String contactNumber=" ";
    boolean verified=false;
    public double rating;
    public void Logout(){
        
    }
    public void Login(){
        
    }
    public void AddPost(){
        
    }
}
