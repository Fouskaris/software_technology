/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package mypackage;

/**
 *
 * @author drago
 */
public class Systemofapp {
    int result=1;
    public boolean LoginDetails(){
        Database db=new Database();
        if (db.CheckCredntials()==false){
            NotValidPass();
        }
        return db.CheckCredntials();
    }
    public void NotValidPass(){
        
    }
    public void TransferRew(){
        
    }
    public void UltimatumSet(){
        
    }
    
    public void CheckRatingForm(/*Form*/){
        //code
        Database db=new Database();
        db.SubmitPost();
    }
    public void BadLanguageDetected(/*Form*/){
        if (result==0){
            Database db=new Database();
            db.CreatesReport();
        }
    }
    public void main(){
        TransferRew();
        CheckRatingForm(/*Form*/);
        BadLanguageDetected(/*Form*/);
        if (result==1){
            Database db=new Database();
            db.NotifiesItemOwner();
        }
    }
}

