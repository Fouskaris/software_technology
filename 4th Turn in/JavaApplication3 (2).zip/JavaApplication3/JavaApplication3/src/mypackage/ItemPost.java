/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package mypackage;

/**
 *
 * @author drago
 */
public class ItemPost {
    int PostId;
    String Postedby=" ";
    String PostAbout=" ";//ItemId
    String Description=" ";
    String Category=" ";
    String PhotoURL=" ";
    String Location=" ";
    public void show(){
        
    }
    public void IfoundThisItemClicked(){
        Systemofapp s=new Systemofapp();
        s.result=1;
    }
    public void IownThisItemClicked(){
        
    }
}
