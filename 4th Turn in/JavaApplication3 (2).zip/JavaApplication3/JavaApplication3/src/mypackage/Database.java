/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package mypackage;

/**
 *
 * @author drago
 */
public class Database {
     public boolean CheckCredntials(){
       
        return true;
    }
    public void SubmitPost(){
        ItemPost a=new ItemPost();
        a.show();
        //submit success
    }
    public void NotifiesItemOwner(){
        
    }
    public void Updates(){
        
    }
     public void Notify(){
        
    }
    public void SaveBusasDropoff(){
        
    }
     public void NotifiesOwner(){
        
    }
    public void SendToBottom(){
        
    }
    public void CreatesReport(){
        
    }
    
}
